
/*
Tony Melo
tmelo1
(201)956-2503
Project 2 - 600.120
2/23/16
*/


int isValid(char c);

int getPatternString(char storePatters[]);

void findOccurances(char dna[], int dnalen, char patternString[]);
